# reporting
Create CSV from proposals

## Install

```bash
npm i
```

## RUN!!!!!!!!

```bash
npm start
```

Once you run the above command, look for a file named something like: `DAO_REPORT_ecosystem.sputnik-dao.near_2021-12-03T20:27:40.869Z.csv`

If you need to make adjustments to this script, open index.js and edit away :)
NOTE: Near price is based on current value only, non-historical

Happy Reporting,
❤️ `tjtc.near`
